package com.cyberark.test.items.services;

import com.cyberark.items.entities.Item;
import com.cyberark.items.services.InMemoryItemService;
import com.cyberark.items.services.ItemService;
import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class InMemoryItemServiceTest {

    private ItemService itemService = new InMemoryItemService();

    @Test
    public void checkScotchBottleQuality()
    {
        List<Item> items = new ArrayList<>();
        Item item = new Item(1, "Scotch Bottle", 10, 10);
        items.add(item);

        itemService.updateQuality(items);
        Assertions.assertThat(item.getQuality()).isEqualTo(11);
    }

    @Test
    public void checkTShirtQuality()
    {
        List<Item> items = new ArrayList<>();
        Item item = new Item(1, "T-Shirt", 10, 10);
        items.add(item);

        itemService.updateQuality(items);
        Assertions.assertThat(item.getQuality()).isEqualTo(9);
    }

    @Test
    public void checkBeerQuality()
    {
        List<Item> items = new ArrayList<Item>();
        Item item = new Item(1, "Beer", 10, 10);
        items.add(item);

        itemService.updateQuality(items);
        Assertions.assertThat(item.getQuality()).isEqualTo(9);
    }

    @Test
    public void checkBasketballQuality()
    {
        List<Item> items = new ArrayList<Item>();
        Item item = new Item(1, "Basketball", 10, 10);
        items.add(item);

        itemService.updateQuality(items);
        Assertions.assertThat(item.getQuality()).isEqualTo(10);
    }

    @Test
    public void checkNoBiggerThan50Quality()
    {
        List<Item> items = new ArrayList<Item>();
        Item item = new Item(1, "Scotch Bottle", 10, 50);
        items.add(item);

        itemService.updateQuality(items);
        Assertions.assertThat(item.getQuality()).isEqualTo(50);
    }

    @Test
    public void checkNoLessThan0Quality()
    {
        List<Item> items = new ArrayList<Item>();
        Item item = new Item(1, "Beer", 10, 0);
        items.add(item);

        itemService.updateQuality(items);
        Assertions.assertThat(item.getQuality()).isEqualTo(0);
    }

    @Test
    public void checkSellinPassQuality2TimeFaster()
    {
        List<Item> items = new ArrayList<Item>();
        Item item = new Item(1, "Beer", 0, 2);
        items.add(item);

        itemService.updateQuality(items);
        Assertions.assertThat(item.getQuality()).isEqualTo(0);
    }

}