package com.cyberark.items.services;

import com.cyberark.items.entities.Item;

import javax.annotation.PostConstruct;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class InMemoryItemService implements ItemService {

    private long idSequence;
    private List<Item> items = new LinkedList<>();

    @PostConstruct
    public void init() {
        idSequence = 1;
        items.add(new Item(idSequence++,"T-Shirt", 10, 20));
        items.add(new Item(idSequence++, "Scotch Bottle", 2, 0));
        items.add(new Item(idSequence++, "Beer", 5, 7));
        items.add(new Item(idSequence++,"Basketball", 0, 50));
    }

    @Override
    public List<Item> getItems() {
        return items;
    }

    @Override
    public Item getItem(long id) {
        Map<Long, Item> itemsMap = items.stream().
                collect(Collectors.toMap(Item::getId, Function.identity()));

        return itemsMap.get(id);
    }

    @Override
    public Item createItem(Item item) {
        if (item == null) {
            return null;
        }

        Item createdItem = new Item(idSequence++, item.getName(), item.getSellIn(), item.getQuality());

        return createdItem;
    }

    @Override
    public void updateQuality(List<Item> items) {
        for (int i = 0; i < items.size(); i++) {
            {
                if (!"Scotch Bottle".equals(items.get(i).getName())) {
                    if (items.get(i).getQuality() > 0) {
                        if (!"Basketball".equals(items.get(i).getName())) {
                            items.get(i).setQuality(items.get(i).getQuality() - 1);
                        }
                    }
                } else {
                    if (items.get(i).getQuality() < 50) {
                        items.get(i).setQuality(items.get(i).getQuality() + 1);
                    }
                }
                if (!"Basketball".equals(items.get(i).getName())) {
                    items.get(i).setSellIn(items.get(i).getSellIn() - 1);
                }
                if (items.get(i).getSellIn() < 0) {
                    if (!"Scotch Bottle".equals(items.get(i).getName())) {
                        if (items.get(i).getQuality() > 0) {
                            items.get(i).setQuality(items.get(i).getQuality() - 1);
                        }
                    } else {
                        if (items.get(i).getQuality() < 50) {
                            items.get(i).setQuality(items.get(i).getQuality() + 1);
                        }
                    }
                }
            }
        }
    }
}